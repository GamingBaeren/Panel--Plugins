<x-filament-widgets::widget>
    {{ $this->content }}
</x-filament-widgets::widget>