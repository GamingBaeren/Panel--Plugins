<?php

namespace Boy132\Billing\Filament\App\Widgets;

use Filament\Widgets\AccountWidget;

class WelcomeWidget extends AccountWidget
{
    protected int|string|array $columnSpan = 'full';
}
